#include <gtest/gtest.h>
#include "Date.h"

TEST(DateTest, isValid_normal_cases) {
  Date date1(0, 0, 0, 0, 0); 		EXPECT_FALSE(Date::isValid(date1));
  Date date2(2013, 1, 1, 10, 10); 	EXPECT_TRUE(Date::isValid(date2));
  Date date3(2013, 1, 31, 10, 10); 	EXPECT_TRUE(Date::isValid(date3));
  Date date4(2013, 2, 28, 10, 10); 	EXPECT_TRUE(Date::isValid(date4));
  Date date5(2013, 3, 30, 10, 10); 	EXPECT_TRUE(Date::isValid(date5));
  Date date6(2852, 10, 9, 5, 57); 	EXPECT_TRUE(Date::isValid(date6));
  Date date7(8481, 5, 6, 8, 90); 	EXPECT_FALSE(Date::isValid(date7));
  Date date8(-1, 7, 28, 10, 10);	EXPECT_FALSE(Date::isValid(date8));
  Date date9(100, 99, 28, 10, 10); 	EXPECT_FALSE(Date::isValid(date9));
  Date date10(100, 8, 38, 10, 10); 	EXPECT_FALSE(Date::isValid(date10));
  Date date11(100, 2, 28, -5, 10); 	EXPECT_FALSE(Date::isValid(date11));
  Date date12(100, 9, 28, 10, -3); 	EXPECT_FALSE(Date::isValid(date12));
}

TEST(DateTest, isValid_boundary_cases) {
  // year
  for(int i=995;i<=999;++i) {
    Date date_tmp(i, 5, 18, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  for(int i=1000;i<=1005;++i) {
    Date date_tmp(i, 5, 18, 10, 10);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=9995;i<=9999;++i) {
    Date date_tmp(i, 5, 18, 10, 10);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=10000;i<=10005;++i) {
    Date date_tmp(i, 5, 18, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  
  // month
  for(int i=-2;i<=0;++i) {
    Date date_tmp(2013, i, 18, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  for(int i=1;i<=12;++i) {
    Date date_tmp(2013, i, 18, 10, 10);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=13;i<=15;++i) {
    Date date_tmp(2013, i, 18, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  
  // day
  for(int i=-3;i<=0;++i) {
    Date date_tmp(2013, 5, i, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  for(int i=1;i<=31;++i) {
    Date date_tmp(2013, 5, i, 10, 10);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=32;i<=35;++i) {
    Date date_tmp(2013, 5, i, 10, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  
  // hour
  for(int i=-3;i<=-1;++i) {
    Date date_tmp(2013, 5, 1, i, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  for(int i=0;i<=23;++i) {
    Date date_tmp(2013, 5, 1, i, 10);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=24;i<=26;++i) {
    Date date_tmp(2013, 5, 1, i, 10);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  
  // minute
  for(int i=-3;i<=-1;++i) {
    Date date_tmp(2013, 5, 1, 5, i);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
  for(int i=0;i<=59;++i) {
    Date date_tmp(2013, 5, 1, 5, i);	EXPECT_TRUE(Date::isValid(date_tmp));
  }
  for(int i=60;i<=63;++i) {
    Date date_tmp(2013, 5, 1, 5, i);	EXPECT_FALSE(Date::isValid(date_tmp));
  }
}

TEST(DateTest, isValid_leap_year_cases) {
  // leap years
  Date date1(1996, 2, 28, 10, 10);	EXPECT_TRUE(Date::isValid(date1));
  Date date2(1996, 2, 29, 10, 10);	EXPECT_TRUE(Date::isValid(date2));
  Date date3(1996, 2, 30, 10, 10);	EXPECT_FALSE(Date::isValid(date3));
  Date date4(2008, 2, 28, 10, 10);	EXPECT_TRUE(Date::isValid(date4));
  Date date5(2008, 2, 29, 10, 10);	EXPECT_TRUE(Date::isValid(date5));
  Date date6(2008, 2, 30, 10, 10);	EXPECT_FALSE(Date::isValid(date6));
  
  // not leap years
  Date date7(1998, 2, 28, 10, 10);	EXPECT_TRUE(Date::isValid(date7));
  Date date8(1998, 2, 29, 10, 10);	EXPECT_FALSE(Date::isValid(date8));
  Date date9(1998, 2, 30, 10, 10);	EXPECT_FALSE(Date::isValid(date9));
  Date date10(2007, 2, 28, 10, 10);	EXPECT_TRUE(Date::isValid(date10));
  Date date11(2007, 2, 29, 10, 10);	EXPECT_FALSE(Date::isValid(date11));
  Date date12(2007, 2, 30, 10, 10);	EXPECT_FALSE(Date::isValid(date12));
}

